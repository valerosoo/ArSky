
<?php
$cliente_nombre=$_POST["Nombre"];
$cliente_apellido=$_POST["Apellido"];
$cliente_documento=$_POST["Documento"];
$cliente_fecha_nacimiento=$_POST["FechaNacimiento"];
$cliente_telefono=$_POST["Telefono"];
$cliente_contraseña=$_POST["Contrasenia"];
$servername = "127.0.0.1"; 
$username = "alumno";      
$password = "alumnoipm";            
$database = "ARSKY";

// Crea una conexión a la base de datos
$conexion = mysqli_connect($servername, $username, $password, $database);

// Verifica la conexión
if (!$conexion) {
    die("Conexión fallida: " . $conexion);
}

if($_SERVER["REQUEST_METHOD"]== "POST"){
    $resultado = mysqli_query($conexion, "INSERT INTO Cliente (DNI, Nombre, Apellido, Telefono, FechaNacimiento, Contrasenia) VALUES ($cliente_documento, '$cliente_nombre', '$cliente_apellido', $cliente_telefono, '$cliente_fecha_nacimiento', '$cliente_contraseña')");
}

?>

    <link rel="stylesheet" href="conexion.css" type="text/css">

    <main>
        <div id="div_borde_login">
            <div id="div_fondo_login">
                <h1>Gracias por Registrarte</h1>
                <p>Haga click <a href="Login_ArSky.html">aqui</a> para iniciar sesion</p>
            </div>
        </div>
    </main>
