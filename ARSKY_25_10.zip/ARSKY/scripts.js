document.addEventListener('DOMContentLoaded', function() {
  const animationContainer = document.getElementById('animation-container');
  const body = document.body;

  // Comprobar si ya hemos mostrado la animación antes
  const hasVisited = localStorage.getItem('hasVisited');

  if (!hasVisited) {
    // Si no hemos visitado antes, añadir la clase 'no-scroll' al body
    body.classList.add('no-scroll');

    animationContainer.style.display = 'flex'; // Asegurarse de que el contenedor de la animación es visible

    animationContainer.addEventListener('animationend', function() {
      // Añadir la clase 'loaded' al body para hacer visible el contenido principal
      body.classList.add('loaded');
      // Eliminar la clase 'no-scroll' para permitir el scroll
      body.classList.remove('no-scroll');
      // Opcionalmente, ocultar el contenedor de la animación

      // Marcar que hemos visitado la página
      localStorage.setItem('hasVisited', 'true');
    });
  } else {
     animationContainer.style.display = 'none';

    // Si ya hemos visitado antes, directamente permitir el scroll
    body.classList.add('loaded');
  }
});

$(document).ready(function() {
  $('#origen-select').select2({
      placeholder: "Seleccione una provincia",
      allowClear: true
  });
});
