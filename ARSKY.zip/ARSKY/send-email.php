<?php
session_start(); 
$DNI=$_SESSION['DNI'];
$email_php = $_POST["email"];
$servername = "127.0.0.1"; 
$username = "alumno";      
$password = "alumnoipm";            
$database = "ARSKY";

// Crea una conexión a la base de datos
$conexion = mysqli_connect($servername, $username, $password, $database);

// Verifica la conexión
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' and !empty($_SESSION['DNI'])){
    $rta_email=mysqli_query($conexion, "UPDATE Cliente SET Email = '$email_php' where DNI=$DNI");
    echo $rta_email;
}
?>
<script>
    setTimeout(function() {
        window.location.href = 'index.php';
    }, 0);
</script> 