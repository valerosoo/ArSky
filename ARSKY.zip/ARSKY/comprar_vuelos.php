<?php
session_start();
$servername = "127.0.0.1";
$username = "alumno"; // Cambia esto si usas otro usuario
$password = "alumnoipm"; // Asegúrate de usar la contraseña correcta
$database = "arsky";
$port = 3306;// Especificamos el puerto aquí
            
$conexion = mysqli_connect($servername, $username, $password, $database, $port);
$id=$_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>comprar</title>
    <link rel="stylesheet" href="comprar_vuelos.css">
    <link rel="icon" href="Logo_Arskyv2.png">
</head>
<body>
    <header>

    </header>
    <main>
        <div id="div_borde_login">
            <div id="div_fondo_login">
                <h1>comprar</h1>
                <form id="formulario_login" action="compra.php" method="POST">
                    <label for="metodo-pago">Elige un método de pago:</label>
                    <select id="metodo-pago" name="metodo-pago">
                        <option value="">Selecciona</option>
                        <option value="1">Visa</option>
                        <option value="2">MasterCard</option>
                        <option value="3">American Express</option>
                    </select>

                    <div id="formulario-pago" style="display: none;">
                        <!-- Formulario Visa -->
                        <div id="visa-form" style="display: none;">
                            <input type="hidden" name="id" value="<?php echo $id ?>">
                            <label for="numero">Número de tarjeta Visa:</label>
                            <input type="text" id="numero" name="numero"  placeholder="Ej: 1234 5678 9012 3456">
                            <label for="nombre-titular">Nombre del Titular:</label>
                            <input type="text" id="nombre-titular" name="nombre-titular"  placeholder="Ej: Juan Pérez">
                            <label for="apellido-titular">Apellido del Titular:</label>
                            <input type="text" id="apellido-titular" name="apellido-titular"  placeholder="Ej: Pérez">
                            <label for="fecha-vencimiento">Fecha de vencimiento:</label>
                            <input type="text" id="fecha-vencimiento" name="fecha-vencimiento" placeholder="MM/AA"  pattern="\d{2}/\d{2}" title="Formato: MM/AA">
                            <label for="cuotoas">Cantidad de cuotas:</label>
                            <input type="text" id="cuotas" name="cant_cuotas" placeholder="Ej: 6">
                            <label for="asiento">Asiento:</label>
                            <input type="text" id="asiento" name="asiento"  placeholder="Ej: A1">
                        </div>

                        <!-- Formulario MasterCard -->
                        <div id="mastercard-form" style="display: none;">
                            <input type="hidden" name="id" value="<?php echo $id ?>">
                            <label for="numero">Número de tarjeta Visa:</label>
                            <input type="text" id="numero" name="numero"  placeholder="Ej: 1234 5678 9012 3456">
                            <label for="nombre-titular">Nombre del Titular:</label>
                            <input type="text" id="nombre-titular" name="nombre-titular"  placeholder="Ej: Juan Pérez">
                            <label for="apellido-titular">Apellido del Titular:</label>
                            <input type="text" id="apellido-titular" name="apellido-titular"  placeholder="Ej: Pérez">
                            <label for="fecha-vencimiento">Fecha de vencimiento:</label>
                            <input type="text" id="fecha-vencimiento" name="fecha-vencimiento" placeholder="MM/AA"  pattern="\d{2}/\d{2}" title="Formato: MM/AA">
                            <label for="cuotoas">Cantidad de cuotas:</label>
                            <input type="text" id="cuotas" name="cant_cuotas" placeholder="Ej: 6">
                            <label for="asiento">Asiento:</label>
                            <input type="text" id="asiento" name="asiento"  placeholder="Ej: A1">
                        </div>
                       

                        <!-- Formulario American Express -->
                        <div id="amex-form" style="display: none;">
                            <input type="hidden" name="id" value="<?php echo $id ?>">
                            <label for="numero">Número de tarjeta Visa:</label>
                            <input type="text" id="numero" name="numero"  placeholder="Ej: 34XXXXXXXXXXXX">
                            <label for="nombre-titular">Nombre del Titular:</label>
                            <input type="text" id="nombre-titular" name="nombre-titular"  placeholder="Ej: Juan Pérez">
                            <label for="apellido-titular">Apellido del Titular:</label>
                            <input type="text" id="apellido-titular" name="apellido-titular"  placeholder="Ej: Pérez">
                            <label for="fecha-vencimiento">Fecha de vencimiento:</label>
                            <input type="text" id="fecha-vencimiento" name="fecha-vencimiento" placeholder="MM/AA"  pattern="\d{2}/\d{2}" title="Formato: MM/AA">
                            <label for="cuotoas">Cantidad de cuotas:</label>
                            <input type="text" id="cuotas" name="cant_cuotas" placeholder="Ej: 6">
                            <label for="asiento">Asiento:</label>
                            <input type="text" id="asiento" name="asiento"  placeholder="Ej: A1">
                        </div>
                    
                    <button id="boton-pagar"  type="submit" style="display: none;">Pagar</button>

                </form>
            </div>

            </div>
        </div>
    </main>

</body>
</html>

<script>
                        const metodoPago = document.getElementById('metodo-pago');
                        const formularioPago = document.getElementById('formulario-pago');
                        const botonPagar = document.getElementById('boton-pagar');

                        metodoPago.addEventListener('change', function() {
                            formularioPago.style.display = 'block';

                            // Ocultar todos los formularios
                            document.getElementById('visa-form').style.display = 'none';
                            document.getElementById('mastercard-form').style.display = 'none';
                            document.getElementById('amex-form').style.display = 'none';
                            botonPagar.style.display = 'none';
                            var inputs = Array.from(document.getElementsByTagName('input'));
                            for(var i = 0; i < inputs.length; ++i){
                                var input = inputs[i];
                                    input.required = false;
                                    input.disabled = true;

                
                            }                            // Mostrar el formulario correspondiente
                            switch (metodoPago.value) {
                                case '1':
                                    var form = document.getElementById('visa-form');
                                    break;
                                case '2':
                                    var form = document.getElementById('mastercard-form');
                                    break;
                                case '3':
                                    var form = document.getElementById('amex-form');
                                    break;
                            }
                            var inputs = Array.from(form.getElementsByTagName('input'));
                            for(var i = 0; i < inputs.length; ++i){
                                var input = inputs[i];
                                    input.required = true;
                                    input.disabled = false;

                
                            }
                            form.style.display = 'block';

                            // Mostrar el botón "Pagar" si se elige un método de pago
                            if (metodoPago.value) {
                                botonPagar.style.display = 'block';
                            } else {
                                botonPagar.style.display = 'none';
                            }
                        });
                    </script>

