<?php
$servername = "127.0.0.1"; 
$username = "alumno";      
$password = "alumnoipm";            
$database = "ARSKY";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener provincias
$sql = "SELECT Provincia FROM Sede";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seleccionar Provincia</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
</head>
<body>
    <select class="input_login" name="origen" id="origen-select">
        <option value="" disabled selected>Seleccione una provincia</option>
        <?php
        if ($result->num_rows > 0) {
            // Salida de cada fila
            while($row = $result->fetch_assoc()) {
                echo "<option value='" . htmlspecialchars($row['Provincia']) . "'>" . htmlspecialchars($row['Provincia']) . "</option>";
            }
        } else {
            echo "<option value='' disabled>No hay provincias disponibles</option>";
        }
        $conn->close();
        ?>
    </select>

    <script>
        $(document).ready(function() {
            $('#origen-select').select2({
                placeholder: "Seleccione una provincia",
                allowClear: true
            });
        });
    </script>
</body>
</html>
