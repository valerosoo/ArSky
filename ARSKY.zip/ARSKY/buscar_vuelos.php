<?php session_start(); 
$destino = $_POST['Destino'];
$origen = $_POST['Origen'];
$fecha_salida = $_POST['Fecha_Salida'];
$fecha_llegada = $_POST['Fecha_Llegada'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar Vuelos</title>
    <link rel="icon" type="image/png" href="Logo Arskyv2.png">
    <link rel="stylesheet" href="buscar_vuelos.css">
</head>
<body>
    <header>
        <div id="img_div">
            <a href="index.php"><img id="img_logo" src="Logo_Arskyv2.png"></a>
        </div>
        <div class="arsky_text">
            <p>Argentina</p>
            <p>Skyes</p>
        </div>
        <div id="div_bloque_celeste_header">
            <a class="a" href="">Mis Vuelos</a>
            <a class="a" href="">Destinos Populares</a>
            <a class="a" href="index.php#Buscar_vuelos">Comprar Vuelos</a>
        </div>
        <div id="div_ayuda_header">
            <img src="https://cdn-icons-png.flaticon.com/512/0/827.png">
            <p>Ayuda</p>
        </div>
        <div id="div_bloque_celeste_header2">
            <?php
            $servername = "127.0.0.1";
            $username = "root"; // Cambia esto si usas otro usuario
            $password = "aa00"; // Asegúrate de usar la contraseña correcta
            $database = "arsky";
            $port = 4000;  // Especificamos el puerto aquí
            
            $conexion = mysqli_connect($servername, $username, $password, $database, $port);
            
            if (!$conexion) {
            die("Connection failed: " . mysqli_connect_error());
            }
            if (isset($_SESSION['DNI'])) {
                // Si la sesión está iniciada, mostrar el nombre y apellido
                echo "<a class='a' href='logout.php'>" . $_SESSION['Nombre'] . " " . $_SESSION['Apellido'] . "</a>";
            } else {
                // Si no hay sesión iniciada, mostrar el enlace para iniciar sesión
                echo "<a class='a' href='Login_ArSky.php'>Iniciar sesión</a>";
            }
            ?>
        </div>
    </header>
    <main>
        <div class="div_centrar">
            <h1>Buscar vuelos</h1>
        </div>
        <div id="div_vuelos">
        <?php
            if (isset($_POST['Origen']) && isset($_POST['Destino']) && isset($_POST['Fecha_Salida']) && isset($_POST['Fecha_Llegada']) && isset($_POST['Fechas_Flex']) && isset($_SESSION['DNI'])){
                $sql = "SELECT Vuelo.*, SedeLlegada.Provincia as Destino, SedeSalida.Provincia as Origen FROM Compra join Boleto on Compra.ID=Compra_ID join Vuelo on Vuelo.ID = Vuelo_ID join Sede SedeSalida on Origen=SedeSalida.ID join Sede SedeLlegada on Destino=SedeLlegada.ID WHERE Destino='$destino';"; // Asegúrate de que esta tabla y columna existen
                $result = mysqli_query($conexion, $sql); //CONSULTA HECHA. USAR ESTA COMO BASE

                if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        $Vuelo_ID=$row['ID'];
                        $_SESSION['Vuelo_ID'] = $Vuelo_ID;
                        ?>
                        <div class="card">
                            <div class="card-details">
                                <p class="text-title">Origen: <?php echo $row['Origen']; ?></p>
                                <p class="text-title">Destino: <?php echo $row['Destino']; ?></p>
                                <p class="text-body">Hora salida: <?php echo $row['Fecha_Salida']; ?></p>
                                <p class="text-body">Hora llegada: <?php echo $row['Fecha_Llegada']; ?></p>
                                <p class="text-body">Código de vuelo: <?php echo $Vuelo_ID; ?></p>
                            </div>
                        </div>
                        <?php
                    }
                } else {
                    echo "<p>No existen vuelos que coincidan con tu búsqueda.</p>";
                }
            }
            else if (isset($_POST['Origen']) && isset($_POST['Destino']) && isset($_POST['Fecha_Salida']) && isset($_POST['Fecha_Llegada']) && isset($_SESSION['DNI'])){
                $sql = "SELECT Vuelo.*, SedeSalida.Provincia as Origen, SedeLlegada.Provincia as Destino 
                FROM Vuelo 
                JOIN Sede SedeSalida ON Vuelo.Origen = SedeSalida.ID 
                JOIN Sede SedeLlegada ON Vuelo.Destino = SedeLlegada.ID
                WHERE SedeSalida.Provincia = '$origen' 
                AND SedeLlegada.Provincia = '$destino' 
                AND Vuelo.Fecha_Salida >= '$fecha_salida' 
                AND Vuelo.Fecha_Llegada <= '$fecha_llegada'";
                $result = mysqli_query($conexion, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        $Vuelo_ID=$row['ID'];
                        $_SESSION['Vuelo_ID'] = $Vuelo_ID;
                        ?>
                        <div class="card">
                            <div class="card-details">
                                <p class="text-title">Origen: <?php echo $row['Origen']; ?></p>
                                <p class="text-title">Destino: <?php echo $row['Destino']; ?></p>
                                <p class="text-body">Hora salida: <?php echo $row['Fecha_Salida']; ?></p>
                                <p class="text-body">Hora llegada: <?php echo $row['Fecha_Llegada']; ?></p>
                                <p class="text-body">Código de vuelo: <?php echo $row['ID']; ?></p>
                            </div>
                        </div>
                        <div>
                            <a href="Comprar_vuelos.php?id="<?php echo $row["ID"]?>><button class="button">Send</button></a>
                        </div>
                        <?php
                    }
                } else {
                    echo "<p>No existen vuelos que coincidan con tu búsqueda.</p>";
                }
            }
            else {
                echo "<p>Inicia sesión para buscar vuelos.</p>";
            }
            
            ?>
        </div>
    </main>
    <footer>
        <div class="main_footer">
            <div class="div_footer">
                <h1>Somos Arsky</h1>
                <p class="text-footer">Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                Consequuntur molestiae qui eum dolorem, tenetur, possimus maxime veniam ex laboriosam
                perspiciatis ullam iusto, soluta consequatur saepe est. Qui voluptatum praesentium magni!</p>
                <a class="text-footer_a" href="www.google.com">¡Conocenos!</a> 
            </div>
            <div class="div_footer">
                <h1>FAQ</h1>
                <ul>
                    <li class="text-footer">ownviownvownvowenv</li>
                    <li class="text-footer">iowbndenienione</li>
                    <li class="text-footer">uorjiojijiodioior</li>
                    <li class="text-footer">ioouihef0hwo0ihied</li>
                    <li class="text-footer">qwuiobheòihw+0j</li>
                    <li class="text-footer">efniuweweoifni</li>
                </ul>
            </div>
            <div class="div_footer">
                <h1>Politicas, Terminos y Condiciones</h1>
                <p class="text-footer">Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                Eum impedit molestias, veritatis pariatur voluptatum quibusdam 
                doloremque nostrum neque autem culpa in quaerat animi earum 
                praesentium distinctio officiis vero dignissimos maxime!</p>
            </div>
        </div>
        <span class="redes-footer">
            <p class="text-body">¡Seguinos en nuestras redes!</p>
            <img src="instagram.png">
            <img src="twitter.png">
            <img src="facebook.png">
        </span>
    </footer>
</body>
</html>


