#include <iostream>
using namespace std;

int a=1;
int b=2;

int main(){
if(a%b==0){
    cout<<"salva está bien"<<endl;
}
else{
    cout<<"salva está mal"<<endl;
}
}