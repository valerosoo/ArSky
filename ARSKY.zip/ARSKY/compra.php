<?php
session_start();
$servername = "127.0.0.1";
$username = "root";
$password = "aa00";
$database = "arsky";
$port = 4000;

$conexion = mysqli_connect($servername, $username, $password, $database, $port);

// Verificar la conexión
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cantCuotas = $_POST['cant_cuotas'];
    $metodoPago = mysqli_real_escape_string($conexion, $_POST['metodo-pago']);
    $tarjeta = mysqli_real_escape_string($conexion, $_POST['numero']);
    $asiento = mysqli_real_escape_string($conexion, $_POST['asiento']);

    $dni = mysqli_real_escape_string($conexion, $_SESSION['DNI']);
    $vueloId = mysqli_real_escape_string($conexion, $_SESSION['Vuelo_ID']);

    // Verificar si la tarjeta existe
    $result = mysqli_query($conexion, "SELECT * FROM tarjeta WHERE Numero='$tarjeta'");
    if (mysqli_num_rows($result) > 0) {
        // Si la tarjeta existe, procede con la actualización
        mysqli_query($conexion, "UPDATE tarjeta SET Cliente_DNI='$dni' WHERE Numero='$tarjeta' and Tipo='2'");
    } else {
        echo "Error: La tarjeta con el número $tarjeta no existe.";
        exit;
    }

    // Inserta la compra en la base de datos
    $sql_compra = "INSERT INTO Compra (Cantidad_Cuotas, fecha, Cliente_ID, Tarjeta) VALUES ($cantCuotas, CURRENT_DATE(), $dni, '$tarjeta')";
    if (mysqli_query($conexion, $sql_compra)) {
        $compra_id = mysqli_insert_id($conexion);

        $sql_precio = "SELECT precio FROM clase JOIN asiento ON Asiento_Clase=clase.ID WHERE asiento.ID='$asiento'";
        $resultado_precio = mysqli_query($conexion, $sql_precio);

        if ($resultado_precio && mysqli_num_rows($resultado_precio) > 0) {
            $fila_precio = mysqli_fetch_assoc($resultado_precio);
            $precio = $fila_precio['precio'];

            // Inserta el boleto
            $sql_boleto = "INSERT INTO Boleto (precio, vuelo_id, compra_id, asiento_id) VALUES ('$precio', '$vueloId', '$compra_id', '$asiento')";
            if (mysqli_query($conexion, $sql_boleto)) {
                echo "Compra realizada con éxito. ID de compra: $compra_id";
            } else {
                echo "Error al insertar el boleto: " . mysqli_error($conexion);
            }
        } else {
            echo "Error al obtener el precio del asiento: " . mysqli_error($conexion);
        }
    } else {
        echo "Error al realizar la compra: " . mysqli_error($conexion);
    }
}

mysqli_close($conexion);

?>
