<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="login5.css" type="text/css">
    <link rel="icon" href="Logo_Arskyv2.png">
</head>
<body>
    <main>
    <div id="div_borde_login">
            <div id="div_fondo_login">
            <h1>Iniciar Sesión</h1>
                <form id="formulario_login" action="check_login.php" method="post">
                    <p>Documento</p>
                    <input class="input_login" type="number" name="Documento" placeholder="ex: 12345678">
                    <p>Contraseña</p>
                    <input class="input_login" type="password" name="Contraseniaphp" placeholder="Contraseña">
                    <div id="div_boton_login">
                    <button class="button">Send</button>
                    </div>
                    <p>¿No tienes una cuenta?   <a href="Register_ArSky.php">Registrarse</a></p>
                </form>
            </div>
    </div>
    </main>
    <footer>

    </footer>
</body>
<script src="scripts.js"></script>
</html>