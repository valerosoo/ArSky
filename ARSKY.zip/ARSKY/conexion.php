<?php
$cliente_nombre = $_POST["Nombre"] ?? '';
$cliente_apellido = $_POST["Apellido"] ?? '';
$cliente_documento = $_POST["Documento"] ?? '';
$cliente_fecha_nacimiento = $_POST["FechaNacimiento"] ?? '';
$cliente_telefono = $_POST["Telefono"] ?? '';
$cliente_contrasenia = $_POST["Contrasenia"] ?? ''; // Corregido aquí

$servername = "127.0.0.1"; 
$username = "alumno";      
$password = "alumnoipm";            
$database = "ARSKY";

// Verifica si hay campos vacíos
if (empty($cliente_nombre) || empty($cliente_apellido) || empty($cliente_documento) || 
    empty($cliente_fecha_nacimiento) || empty($cliente_telefono) || empty($cliente_contrasenia)) { // Corregido aquí
    echo "<h3>Todos los campos son obligatorios.</h3>";
    echo "<p>Por favor, completa todos los campos.</p>";
    echo "<script>
            setTimeout(function() {
                window.location.href = 'Register_ArSky.php'; // Redirigir al formulario
            }, 3000);
          </script>";
    exit();
}

// Crea una conexión a la base de datos
$conexion = new mysqli($servername, $username, $password, $database);

// Verifica la conexión
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Prepara la consulta
$stmt = $conexion->prepare("INSERT INTO Cliente (DNI, Nombre, Apellido, Telefono, FechaNacimiento, Contrasenia) VALUES (?, ?, ?, ?, ?, ?)");
if ($stmt === false) {
    die("Error al preparar la consulta: " . $conexion->error);
}

// Hashea la contraseña antes de almacenarla
$hashed_password = password_hash($cliente_contrasenia, PASSWORD_DEFAULT);

// Vincula los parámetros
$stmt->bind_param("ssssss", $cliente_documento, $cliente_nombre, $cliente_apellido, $cliente_telefono, $cliente_fecha_nacimiento, $hashed_password); // Usar $hashed_password

// Ejecuta la consulta
try {
    $stmt->execute();
    ?>
    <link rel="stylesheet" href="conexion.css" type="text/css">
    <main>
        <div id="div_borde_login">
            <div id="div_fondo_login">
                <h1>Gracias por Registrarte</h1>
                <p>Pronto serás redirigido para iniciar sesión</p>
            </div>
        </div>
    </main>
    <?php
    echo "<script>
            setTimeout(function() {
                window.location.href = 'Login_ArSky.php';
            }, 3000);
          </script>";
} catch (mysqli_sql_exception $e) {
    if ($e->getCode() == 1062) { // Error de entrada duplicada
        echo "<h3>Cuenta ya existe.</h3>";
        echo "<p>Serás redirigido en 3 segundos...</p>";
        echo "<script>
                setTimeout(function() {
                    window.location.href = 'Register_ArSky.php';
                }, 3000);
              </script>";
    } else {
        echo "Error al insertar el registro: " . $e->getMessage();
    }
}

// Cierra la declaración
$stmt->close();

// Cierra la conexión
$conexion->close();
?>
