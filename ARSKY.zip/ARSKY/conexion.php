
<?php
$cliente_nombre=$_POST["Nombre"];
$cliente_apellido=$_POST["Apellido"];
$cliente_documento=$_POST["Documento"];
$cliente_fecha_nacimiento=$_POST["FechaNacimiento"];
$cliente_telefono=$_POST["Telefono"];
$cliente_contraseña=$_POST["Contrasenia"];
$passwordh=password_hash($cliente_contraseña, PASSWORD_DEFAULT);
$servername = "127.0.0.1";
$username = "alumno"; // Cambia esto si usas otro usuario
$password = "alumnoipm"; // Asegúrate de usar la contraseña correcta
$database = "arsky";
$port = 3306; // Especificamos el puerto aquí

$conexion = mysqli_connect($servername, $username, $password, $database, $port);


// Verifica la conexión
if (!$conexion) {
    die("Conexión fallida: " . $conexion);
}
if($_SERVER["REQUEST_METHOD"]== "POST"){
    $resultado = mysqli_query($conexion, "INSERT INTO cliente (DNI, Nombre, Apellido, Telefono, FechaNacimiento, Contrasenia) VALUES ($cliente_documento, '$cliente_nombre', '$cliente_apellido', $cliente_telefono, '$cliente_fecha_nacimiento', '$passwordh')");
}

?>

    <link rel="stylesheet" href="conexion.css" type="text/css">

    <main>
        <div id="div_borde_login">
            <div id="div_fondo_login">
                <h1>Gracias por Registrarte</h1>
                <p>Haga click <a href="Login_ArSky.php">aqui</a> para iniciar sesion</p>
            </div>
        </div>
    </main>
