<?php 
session_start();
$servername = "127.0.0.1";
$username = "alumno"; // Cambia esto si usas otro usuario
$password = "alumnoipm"; // Asegúrate de usar la contraseña correcta
$database = "arsky";
$port = 3306;
session_destroy();
?>
 <!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Redirigiendo...</title>
        <link href="check_login.css" rel="stylesheet">
    </head>
    <body>
    <main>
        <div id='div_borde_login'>
            <div id='div_fondo_login'>
                <p>¡Cerrando Sesión! Redirigiendo...</p>
            </div>
        </div>
        <script>
            setTimeout(function() {
                window.location.href = 'index.php';
            }, 3000);
        </script>
    </main>  
    </body>
    </html>