create database ARSKY;
use ARSKY;

create table MétodoPago(
    ID int primary key,
    Nombre varchar(45)
);

create TABLE Clase(
    ID int primary key,
    Nombre varchar(45)
);

create table Tipo_Tarjeta(
    Codigo int primary key,
    Nombre varchar(45)
);

Create TABLE Sede(
    ID int primary KEY,
    Provincia varchar(45)
);

create table Cliente(
    DNI int PRIMARY key,
    Nombre varchar(45),
    Apellido varchar(45),
    Teléfono int,
    Email varchar(45),
    FechaNacimiento date,
    Contraseña varchar(45)
);

CREATE TABLE Tarjeta(
    Numero int primary key,
    Num_Seguridad int,
    Fecha_Cad DATE,
    Cliente_DNI int,
    FOREIGN key (Cliente_DNI) REFERENCES Cliente (DNI),
    Tipo int,
    FOREIGN key (Tipo) REFERENCES Tipo_Tarjeta (Codigo)
);

create table Aviones(
    Matrícula varchar(6) PRIMARY KEY,
    Modelo varchar(45),
    Asientos_Primera int,    
    Asientos_Bussiness int,
    Asientos_Economica int
);

create table Asiento(
    ID varchar(45) primary key,
    Clase varchar(45),
    FOREIGN KEY (Clase) REFERENCES Clase (ID),
    Avion varchar(6),
    FOREIGN KEY (Avion) REFERENCES Aviones (Matrícula)
);

CREATE table Compra(
    ID int primary key,
    Cantidad_Cuotas int,
    Fecha DATETIME,
    MetodoPago int,
    FOREIGN KEY (MetodoPago) REFERENCES MetodoPago (ID),
    Cliente_ID int,
    FOREIGN KEY (Cliente_ID) REFERENCES Cliente (DNI),
    Tarjeta int,
    FOREIGN KEY (Tarjeta) REFERENCES Tarjeta (Numero)
);


create table Vuelo(
    ID int primary KEY,
    Origen int,
    Destino int,
    FOREIGN key (Origen) REFERENCES Sede (ID),
    FOREIGN key (Destino) REFERENCES Sede (ID),
    Fecha_Salida datetime,
    Fecha_Llegada datetime,
    Avion varchar(6)
    FOREIGN KEY (Avion) REFERENCES Aviones (Matrícula)
);

create table Boleto(
    ID int primary key,
    Precio INT,
    Vuelo_ID int,
    Foreign key (Vuelo) REFERENCES Vuelo (ID),
    Clase_ID int,
    FOREIGN KEY (Clase_ID) REFERENCES Clase (ID),
    Compra_ID int,
    FOREIGN KEY (Compra_ID) REFERENCES Compra (ID),
    Asiento_ID int,
    FOREIGN KEY (Asiento_ID) REFERENCES Asiento (ID),
);