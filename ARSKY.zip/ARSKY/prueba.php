<?php
session_start();

// Set a session variable
$_SESSION['nombre'] = 'Negri';

// Access the session variable
echo $_SESSION['nombre'];

// Destroy the session
session_destroy();
?>